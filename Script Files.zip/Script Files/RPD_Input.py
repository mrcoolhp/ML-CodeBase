import os
import sys
import datetime
import errno
import re
import time
import shutil
import zipfile
from shutil import copyfile
import weblogic.security.internal.SerializedSystemIni
import weblogic.security.internal.encryption.ClearOrEncryptedService
class RPDTools:
	def __init__(self):
		#Folder related initializers
		self.ifilePath="G:\\Input"
		self.foldername=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
		self.deployment="G:\\98_Deployment\\RPD"
		self.backup="G:\\99_Backup\\RPD"
		os.makedirs(os.path.join(self.backup,self.foldername))
		os.makedirs(os.path.join(self.deployment,self.foldername))
		self.mydir=os.path.join(self.backup,self.foldername)
		self.tmp=os.path.join(self.backup,self.foldername,"tmp")
		self.logarchiveFolder="G:\OBIRBCCM\log\logarchive"
		self.xdotempFolder="C:\\Users\\harip\\AppData\\Local\\Temp"
		
		#Password related initializers
		obiDomainPath = os.path.abspath("G://MWHOME12.2.1.4//user_projects//domains//bi")
		encryptSrv = weblogic.security.internal.SerializedSystemIni.getEncryptionService(obiDomainPath)
		ces = weblogic.security.internal.encryption.ClearOrEncryptedService(encryptSrv)
		credential=[line.rstrip('\n') for line in open("G://OBIRBCCM//Deployment_Manager//admin.properties","r")]
		cred=credential[0].split(":")
		username=cred[1]
		self.obiUsername = ces.decrypt(username)
		cred=credential[1].split(":")
		password=cred[1]
		self.obiPassword = ces.decrypt(password)
		self.rpdPassword="Admin123"
		
		#RPD related initializers
		self.projlist=''
		self.patchproj=sys.argv[1]#"G:\\Stage\\"
		self.blankrpd="G:\\OBIRBCCM\\Deployment_Manager\\Blank.rpd"
		self.stagerpd=""
		self.baserpd=""
		self.extractrpd=""
		self.patchxml=""
		self.patchedrpd=""
		self.patchprojlist=""
		self.patchprojfile=sys.argv[1]+"\\Projlist_"+datetime.datetime.now().strftime('%Y%m%d')+".txt"
		
		#Log file related initializers
		self.logpath="G:\\OBIRBCCM\\log\\"
		self.errorLog="G:\\OBIRBCCM\\log\\auto_rpdlog.log" #RPD output and error log.
		self.actionLog="G:\\OBIRBCCM\\log\\RPDAdmintool.log" #Webcat Script command log, contains all the commands executed by the script.
		self.clientname="RBCCM"
		
		#Command file related initializers
		self.statuscommand="G:\\MWHOME12.2.1.4\\user_projects\\domains\\bi\\bitools\\bin\\status.cmd"
		self.datamodelcommand="G:\\MWHOME12.2.1.4\\user_projects\\domains\\bi\\bitools\\bin\\datamodel.cmd"
		self.createxmlcommand="G:\\MWHOME12.2.1.4\\user_projects\\domains\\bi\\bitools\\bin\\comparerpd.cmd"
		self.createrpdcommand="G:\\MWHOME12.2.1.4\\user_projects\\domains\\bi\\bitools\\bin\\biserverxmlexec.cmd"
		
		#Command Execution Check initializers
		self.downloadfailcheck=0
		self.prepfailcheck=0
		self.extractfailcheck=0
		self.createxmlcheck=0
		self.createrpdcheck=0
		self.uploadrpdcheck=0


		
	def log_writer(self,filename,cmd):
		file=open(filename,"a+")
		file.write(cmd+"\n")
		file.close()
 
	def check_status(self):
		os.system(self.statuscommand+" >> "+self.errorLog+" 2>&1")
		self.log_writer(self.actionLog,"<"+datetime.datetime.now().strftime('%b %d, %Y %I:%M:%S %p')+">"+",STATUS CHECK,"+os.getlogin()+";")

	def prepare_rpd(self):
		try:
			#self.download_rpd()  ## should delete
			#os.makedirs(os.path.join(self.tmp,"tmp"))  ## should delete
			
			print("Preparing RPD")
			#os.makedirs(os.path.join(self.tmp,"tmp")) ## should delete
			patchstring=''
			list_of_files=[os.path.basename(x) for x in glob.glob(sys.argv[1]+"\\*\\*")]#os.listdir('G:\\Stage\\')
			
			
			#for p in list_of_files:
			#	print(p)
			#print(input("list_of_files"))
			list_of_rpd=[]
			if os.path.isfile(self.patchprojfile):
				self.patchprojlist=[line.rstrip('\n') for line in open(self.patchprojfile,"r")]
				self.patchprojlist.sort()
				for item in self.patchprojlist:
					item=item[:item.rfind('\\')]
					for file in list_of_files:
						
						if file==(item.rstrip()+".rpd"): #file.startswith(item.rstrip())
							tmp=os.path.join(self.patchproj,item,file)
							list_of_rpd.append(tmp)
					
				#for p in list_of_rpd:
				#	print(p+"list_of_rpd\n")
				#print("length of list of RPD"+str(len(list_of_rpd)))
				for i in range(len(list_of_rpd)):
					self.log_writer(self.errorLog,"\n\nWorking on Source "+list_of_rpd[i]+".rpd")
					prepcmd=self.createxmlcommand+" -P "+self.rpdPassword+" -W "+self.rpdPassword+" -C \""+list_of_rpd[i]+"\" -G "+self.blankrpd+" -F "+self.tmp+"\\output"+str(i)+".xml"+" -8 > "+self.tmp+"\\tmp.txt"
					#print(prepcmd)
					os.system(prepcmd+" >> "+self.errorLog+" 2>&1")
					print(".......")
					patchstring=patchstring+" -I "+self.tmp+"\\output"+str(i)+".xml"
				#print(patchstring+str(input("test")))
				prepcmd=self.createrpdcommand+" -P "+self.rpdPassword+patchstring+" -B "+self.blankrpd+" -O "+os.path.join(self.backup,self.foldername)+"\\"+self.clientname+"_stage.rpd > "+self.tmp+"\\tmp.txt"
				os.system(prepcmd+" >> "+self.errorLog+" 2>&1")
				self.stagerpd=os.path.join(self.backup,self.foldername)+"\\"+self.clientname+"_stage.rpd"
				self.log_writer(self.actionLog,"<"+datetime.datetime.now().strftime('%b %d, %Y %I:%M:%S %p')+">"+",PREPARERPD,"+os.getlogin()+","+prepcmd+";"+"\n")
				shutil.rmtree(self.tmp)
				print("End Prepare")
				return 1
	
			else:
				print("Please check Project List file exist in the staging folder\n(format: Projlist_YYYYMMDD.txt)")
				self.prepfailcheck=1
				return 0
  
			
		
		except Exception,e:
			self.prepfailcheck=1
			print("Exception"+e)
			return 0
		

		


		
	def download_rpd(self):
		try:
			#obiPass=str(raw_input("Enter OBI Password :")) #-O #
			dwncmdstr=" downloadrpd "+"-O "+self.mydir+"\\"+self.clientname+".rpd -W "+self.rpdPassword+" -SI ssi -Y -U "+self.obiUsername+" -P "+self.obiPassword
			dwncmd=self.datamodelcommand+dwncmdstr
			os.system(dwncmd+" >> "+self.errorLog+" 2>&1")
			self.baserpd=os.path.join(self.mydir+"\\"+self.clientname+".rpd")
			self.log_writer(self.actionLog,"<"+datetime.datetime.now().strftime('%b %d, %Y %I:%M:%S %p')+">"+",DOWLOADRPD,"+os.getlogin()+","+dwncmd+";"+"\n")

			if os.path.isfile(self.baserpd):
				print("Downloaded at "+self.mydir+"\\"+self.clientname+".rpd") #getConnPool
                
				self.getConnPool()
				self.log_writer(self.errorLog,"Download RPD available at "+self.mydir+"\\"+self.clientname+".rpd")
				return 1
			else:
				print("\nRPD was not download due to below issue with the command\n")
				self.downloadfailcheck=1
				return 0
		except Exception,e:
			#Test#
			db="\n RPD Download Failed\n"+e
			self.downloadfailcheck=1
			self.log_writer(self.errorLog,db)
			return 0

	def view_projlist(self):
		try:
			print("Enter 1 to use Last Downloaded RPD path or 2 to enter new RPD path")
			itr=int(input())
			if(itr==1):
				eprjrpdbase=os.path.join(self.backup,self.foldername)+"\\"+self.clientname+".rpd"
				if os.path.isfile(eprjrpdbase):
					projfile=self.mydir+"\\Projlist_"+datetime.datetime.now().strftime('%Y%m%d')+".txt"
					cmd=" -B "+eprjrpdbase+" -P "+self.rpdPassword+" -E "+projfile
					cmd="C:\\RPD_Manager\\extract.bat"+cmd
					os.system(cmd)
					self.projlist=[line.rstrip('\n') for line in open(projfile,"r")]
					self.projlist.sort()
					for item in self.projlist:
						print(self.projlist.index(item)+1,item)
				else:
					print("RPD not yet downloaded,Please download the RPD first and try to view the Projects")
					return
			elif(itr==2):
				print("Enter the RPD Path to View the Project List:")
				eprjrpdbase=raw_input()
				if os.path.isfile(eprjrpdbase) and eprjrpdbase[-4:]=='.rpd':
					projfile=self.mydir+"\\Projlist_"+datetime.datetime.now().strftime('%Y%m%d')+".txt"
					cmd=" -B "+eprjrpdbase+" -P "+self.rpdPassword+" -E "+projfile
					cmd="C:\\RPD_Manager\\extract.bat"+cmd
					os.system(cmd)
					self.projlist=[line.rstrip('\n') for line in open(projfile,"r")]
					self.projlist.sort()
					for item in self.projlist:
						print(self.projlist.index(item)+1,item)
				else:
					print("RPD does not exists in the given path,Please mention the correct path")
					return
			else:
				print("Invalid Option - Please try again")
				return
		except:
			print("Download Failed")

			
			
	def extract_project(self):
		try:
			
			#eprjrpdbase=os.path.join(self.backup,self.foldername)+"\\"+self.clientname+".rpd"
			if os.path.isfile(self.baserpd):
				os.makedirs(os.path.join(self.tmp,"tmp"))
				
				self.prepare_rpd()
				if(self.prepfailcheck==1 or not os.path.isfile(self.stagerpd)):
					print("Prepare RPD failed. Please check the RPD error logs.")
					return
				else:
					getproj=self.patchprojlist
					counter=0
					maxind=len(getproj)-1
					proj=""
					while counter <= maxind:
						if(getproj[counter] in self.patchprojlist):
							projname=getproj[counter][getproj[counter].rfind("\\")+1:]
						 
							proj=proj+" -I "+projname
						else:
							print(getproj[counter]+" not in the project list")
						counter+=1 
					#print(proj)
					if(proj==''):
						print("No project to extract")
						return
					#print(eprjrpdbase)
					extrcmd=" -B "+self.baserpd+" -P "+self.rpdPassword+" -O "+os.path.join(self.backup,self.foldername)+"\\"+self.clientname+"_extract.rpd"+proj
					extrcmd="G:\\MWHOME12.2.1.4\\user_projects\\domains\\bi\\bitools\\bin\\extractprojects.cmd"+extrcmd
					os.system(extrcmd+" >> "+self.errorLog+" 2>&1")
					self.extractrpd=os.path.join(self.backup,self.foldername+"\\"+self.clientname+"_extract.rpd")
					print("\nExtract RPD at "+os.path.join(self.backup,self.foldername)+"\\"+self.clientname+"_extract.rpd")
					self.log_writer(self.errorLog,"\nExtract RPD available at "+os.path.join(self.backup,self.foldername)+"\\"+self.clientname+"_extract.rpd\n\n")
					self.log_writer(self.actionLog,"<"+datetime.datetime.now().strftime('%b %d, %Y %I:%M:%S %p')+">"+",EXTRACT PROJECT,"+os.getlogin()+","+extrcmd+";"+"\n")
				return 1
			else:
				print("Download RPD does not exists in the given path")
				return 0
			
		except Exception,e:
			print("Extract Project not completed either due to invalid option or invalid RPD"+"\n"+e)
			db="\nExtract Project not completed either due to invalid option or invalid RPD\n"+e
			self.extractfailcheck=1
			self.log_writer(self.errorLog,db)
			return 0

	def create_patch(self):
		try:
			originalrpd=self.stagerpd #str(raw_input())
			modifiedrpd=self.extractrpd #str(raw_input())
			if os.path.isfile(originalrpd) and os.path.isfile(modifiedrpd) and self.extractfailcheck==0:
				createpatchcmd=self.createxmlcommand+" -P "+self.rpdPassword+" -W "+self.rpdPassword+" -C "+originalrpd+" -G "+modifiedrpd+" -F "+os.path.join(self.backup,self.foldername)+"\\output.xml"+" -8"
				os.system(createpatchcmd+" >> "+self.errorLog+" 2>&1")
				print("Patch File Created at "+os.path.join(self.backup,self.foldername)+"\\output.xml")
				self.patchxml=os.path.join(self.backup,self.foldername)+"\\output.xml"
				self.log_writer(self.actionLog,"<"+datetime.datetime.now().strftime('%b %d, %Y %I:%M:%S %p')+">"+",Patch XML,"+os.getlogin()+"\n")
				
				createpatchcmd=self.createxmlcommand+" -P "+self.rpdPassword+" -W "+self.rpdPassword+" -C "+originalrpd+" -G "+modifiedrpd+" -O "+os.path.join(self.backup,self.foldername)+"\\CompareReport.csv"
				os.system(createpatchcmd+" >> "+self.errorLog+" 2>&1")
				return 1
			else:
				print("Patch XML file not since Original RPD or Extract RPD is not available.")
				self.createxmlcheck=1
				return 0
		except Exception,e:
			print("Patch XML file not created"+"\n"+e)
			db="\nPatch XML file not created\n"+e
			self.createxmlcheck=1
			self.log_writer(self.errorLog,db)
			return 0

	def patchrpd(self):
		try:
			baserpd=self.baserpd
			if os.path.isfile(self.baserpd) and os.path.isfile(self.patchxml) and self.createxmlcheck<>1:
				cmd=self.createrpdcommand+" -P "+self.rpdPassword+" -I "+os.path.join(self.backup,self.foldername)+"\\output.xml"+" -B "+baserpd+" -O "+os.path.join(self.backup,self.foldername)+"\\"+self.clientname+"_final.rpd"
				os.system(cmd+" >> "+self.errorLog+" 2>&1")
				srcpatched=os.path.join(self.backup,self.foldername)+"\\"+self.clientname+"_final.rpd"
				self.patchedrpd=self.deployment+"\\Upload"+"\\"+self.clientname+"_final.rpd"
				copyfile(srcpatched,self.patchedrpd)
				print("Patch RPD Created at "+self.patchedrpd+" and available for Upload")
				self.log_writer(self.actionLog,"<"+datetime.datetime.now().strftime('%b %d, %Y %I:%M:%S %p')+">"+",Patch RPD,"+os.getlogin()+"\n")
				return 1
			else:
				print("Patch File not created")
				return 0
		
		except Exception,e:
			print("Patch RPD file not created"+"\n"+e)
			db="\nPatch RPD file not created\n"+e
			self.createrpdcheck=1
			self.log_writer(self.errorLog,db)
			return 0

			
	def uploadrpd(self):
  
		try:
			#uploadrpd=self.deployment+"\\Upload"+"\\"+self.clientname+"_final.rpd"
			if os.path.isfile(self.patchedrpd):
				#obiPass=str(raw_input("Enter OBI Password :"))
				updcmd=" uploadrpd "+"-I "+self.patchedrpd+" -W "+self.rpdPassword+" -SI ssi -U "+self.obiUsername+" -P "+self.obiPassword
				updcmd=self.datamodelcommand+updcmd
				
				os.system(updcmd+" >> "+self.errorLog+" 2>&1")   #UNCOMMENT 
				
				
				self.log_writer(self.actionLog,"<"+datetime.datetime.now().strftime('%b %d, %Y %I:%M:%S %p')+">"+",Upload RPD,"+os.getlogin()+"\n")
				self.updateConnPool()
				
				#Ufoldername="Upload_"+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
				#os.makedirs(os.path.join(self.deployment,foldername))
				dst=os.path.join(self.deployment,self.foldername)+"\\"+self.clientname+"_final.rpd"
				copyfile(self.patchedrpd,dst)
				self.uploadrpdcheck=1
				return 1
				
			else:
				print("Upload RPD file does not exists or please check the file name")
				self.uploadrpdcheck=0
				return 0
				
		except Exception,e:  
			print("RPD not uploaded,RPD file does not exist or incorrect file name\n"+e)
			self.uploadrpdcheck=0
			return 0
 
	def getConnPool(self):
		try:
			obiPass=self.obiPassword#str(raw_input("Enter OBI Password :"))
			cmd=" listConnectionpool "+"-O "+"G:\\OBIRBCCM\\Deployment_Manager"+"\\"+self.clientname+".json"+" -SI ssi -U "+self.obiUsername+" -P "+obiPass
			cmd=self.datamodelcommand+cmd
			os.system(cmd+" >> "+self.errorLog+" 2>&1")
			return
		except Exception,e:
			print("UpdateConnection Pool Failed")
   
	def updateConnPool(self):
		try:
			obiPass=self.obiPassword#str(raw_input("Enter OBI Password :"))
			cmd=" updateconnectionpool "+"-C "+"G:\\OBIRBCCM\\Deployment_Manager"+"\\"+self.clientname+".json"+" -SI ssi -U "+self.obiUsername+" -P "+obiPass
			cmd=self.datamodelcommand+cmd
			#print("Connection Pool Update Command\n"+cmd)
			print(os.system(cmd+" >> "+self.errorLog+" 2>&1"))
			print("Update Connection Pool Completed")
			return
		except Exception,e:
			print("UpdateConnection Pool Failed")


            
	def log_rotate(self):
		if os.path.isfile(self.errorLog):
			lt=os.path.getmtime(os.path.join(self.errorLog))
			arclogfile=self.logarchiveFolder+"\\"+"auto_rpdlog_"+datetime.datetime.fromtimestamp(lt).strftime('%Y%m%d_%H%M%S')+".log"
			copyfile(self.errorLog,arclogfile) # Performs file copy operation to logarchive folder.
			now=datetime.datetime.now() #get the current datetime 2018-11-19 10:22:10.242000
			arch5=datetime.timedelta(30) #Day Parameter: 30 days, 0:00:00
			cutoff=now-arch5 # Determines the cutoff Date  2018-10-20 10:22:10.242000
			files=os.listdir(self.logarchiveFolder)  #get the file names under log archive folder
			for file in files:
		#for each file get the time stamp, compare with cutoff time, if filestamp is less then cutoff, then remove the file.
				if os.path.isfile((os.path.join(self.logarchiveFolder,file))):
					t=os.path.getmtime(os.path.join(self.logarchiveFolder,file))
					ct=datetime.datetime.fromtimestamp(t)
					if ct < cutoff:
						os.remove(os.path.join(self.logarchiveFolder,file)) #print(os.path.join(self.logarchiveFolder,file)) # Remove File
		else:
			log=open(self.errorLog,"w+")
			log.close()
			
	def xdo_file_delete(self):
		if os.path.isdir(self.xdotempFolder):
			lt=os.path.getmtime(os.path.join(self.xdotempFolder))
			rem=0
			
			now=datetime.datetime.now() #get the current datetime 2018-11-19 10:22:10.242000
			del15=datetime.timedelta(15) #Day Parameter: 30 days, 0:00:00
			cutoff=now-del15 # Determines the cutoff Date  2018-10-20 10:22:10.242000
			files=os.listdir(self.xdotempFolder)  #get the file names under log archive folder
			for file in files:
				
				#for each file get the time stamp, compare with cutoff time, if filestamp is less then cutoff, then remove the file.
				if os.path.isfile(os.path.join(self.xdotempFolder,file)) and (file[:3]=="xdo" and (file[-4:]==".tmp" or file[-3:]==".id"or file[-3:]==".st")):
					t=os.path.getmtime(os.path.join(self.xdotempFolder,file))
					ct=datetime.datetime.fromtimestamp(t)
					if ct < cutoff:
						#print(file)
						os.remove(os.path.join(self.xdotempFolder,file)) #print(os.path.join(self.xdotempFolder,file)) # Remove File
						rem=1
			if rem==1:
				return 1
			else:
				return 0
		else:
			return 0
	
			
	def script_start(self,InputPath):
		self.log_rotate()
		self.xdo_file_delete()
		file=open(self.errorLog,"w+")
		file.close()
		itr=1
		while(itr<>99):
			print("\nRBC RPD Management Tool")
			#print("Enter 1 to find the status of services")
			print("Enter 1 to Download RPD")
			
			print("Enter 2 to Extract Projects")
			print("Enter 3 to Create Patch File")
			print("Enter 4 to Create Patch RPD")
			print("Enter 5 to Upload RPD")
			print("Enter 99 to End the Script")
			try:
				getOption=int(input("Enter a Number :  "))
				if 0==1:
					#status=self.check_status()
					if status==1:
						print("Status Check Completed")
				elif getOption==1:
					status=self.download_rpd()
					if status==1:
						print("RPD Download Completed")
					else:
						print("RPD was not downloaded")
				#elif getOption==3:
					#status=self.prepare_rpd()
				elif getOption==2 and self.downloadfailcheck==0:
					status=self.extract_project()
					if status==1:
						print("RPD Extract Completed")
					else:
						print("RPD Extract not completed")
					
				elif getOption==3 and self.extractfailcheck==0:
					status=self.create_patch()
					if status==1:
						print("Patch XML Created")
					else:
						print("Patch XML not Created")
				elif getOption==4 and self.createxmlcheck==0:
					status=self.patchrpd()#self.getConnPool()
					if status==1:
						print("Patch RPD Created")
					else:
						print("Patch RPD not Created")
				elif getOption==5 and self.createrpdcheck==0:
					status=self.uploadrpd()
					if status==1:
						print("RPD has been uploaded successfully.")
					else:
						print("RPD upload failed")
				elif getOption==7:
					status=self.xdo_file_delete()
					if status==1:
						print("XDO files has been deleted")
					else:
						print("XDO files not deleted")		
				elif getOption==99:
					if len(os.listdir(self.mydir))==0:
						os.rmdir(self.mydir)
					if len(os.listdir(os.path.join(self.deployment,self.foldername)))==0:
						os.rmdir(os.path.join(self.deployment,self.foldername))
						
					break
				else:
					print("Option does not exists, Please enter correct Option")   
			except Exception,e:		
				print("Exception Error"+str(e))
				itr=1
				continue
			status=0
			itr=getOption 


	
	
	
def main():
	obj=RPDTools()
	script_start=obj.script_start(sys.argv[1])
	
			
if __name__=='main':
	main()
#print(input("Exit Input :"))