import os
import sys
import datetime
import errno
import re
import time
import shutil
import zipfile
import traceback
from shutil import copyfile
import weblogic.security.internal.SerializedSystemIni
import weblogic.security.internal.encryption.ClearOrEncryptedService
class WebcatTools:
 def __init__(self):
  """ This section is construction section of python object. Like initialization block for the script"""
  
  configPath=[line.rstrip('\n') for line in open(os.path.abspath(os.path.dirname(sys.argv[0])+"\\Webcat.config"),"r")]
  """Script config file pointing to "G://OBIRBCCM//Deployment_Manager//Webcat.config" contains Webcat path,Webcat Service URL
  and Webcat error list to validate the error logs"""
  wcPath=configPath[0].split("=")
  self.catalogPath=os.path.join(wcPath[1])
  wcPath=configPath[1].split("=")
  self.srvcurl=wcPath[1]
  errList=configPath[2].split("=")
  self.wcerrList=errList[1].split(',')
  self.ifilePath="G:\\Input" # Standard Input Location - Catalog Files must be placed under this location when using Batch.csv file
  
  self.errorLog="G:\\OBIRBCCM\\log\\auto_wclog.log" #Webcat output and error log.
  self.actionLog="G:\\OBIRBCCM\\log\\WebcatLog.log" #Webcat Script command log, contains all the commands executed by the script.
  self.logarchiveFolder="G:\\OBIRBCCM\\log\\logarchive"  #Log Archive location - On each script invoke, auto_wclog.log will be taken backup and stored under archive location
  self.catmanFile="G:\\OBIRBCCM\\Deployment_Manager\\catman.properties" #credential file used to turn on/off maintenance mode, created and destroyed during script execution
  self.maintenanceInd="OFF" # Webcat Maintenance mode indicator - Used within the script
    
  self.runcatPath="G:\\MWHOME12.2.1.4\\user_projects\\domains\\bi\\bitools\\bin\\runcat.cmd" # Location of the Catalog Manager cmd file.
    
  self.backup="G:\\99_Backup\\WebCat_Auto" # Default Backup location
  self.deployment="G:\\98_Deployment\\WebCat_Auto" # Default Deployment Location
  self.foldername=datetime.datetime.now().strftime('%Y%m%d_%H%M%S') #DataTimeStamp Folder created under default backup and deployment location.
  os.makedirs(os.path.join(self.backup,self.foldername)) #Create DateTimeStamp Folder under Backup Location
  os.makedirs(os.path.join(self.deployment,self.foldername)) #Create DateTimeStamp Folder under Deployment Location
  
  obiDomainPath = os.path.abspath(os.environ['DOMAIN_HOME']) #retrives OBI Domain Home location from the environment variable.
  encryptSrv = weblogic.security.internal.SerializedSystemIni.getEncryptionService(obiDomainPath) #commands to encrypt and decrypt obiadmin credentials
  ces = weblogic.security.internal.encryption.ClearOrEncryptedService(encryptSrv)
  credential=[line.rstrip('\n') for line in open(os.path.abspath(os.path.dirname(sys.argv[0]))+"\\admin.properties","r")]
  cred=credential[0].split(":")
  username=cred[1]
  self.obiUsername = ces.decrypt(username)
  cred=credential[1].split(":")
  password=cred[1]
  self.outBatch=os.path.join(self.backup,self.foldername,"outBatch.csv")
  self.obiPassword = ces.decrypt(password)
  
  
	
 def archive_webcat(self,commandfile):
  self.print_to_screen("Opening Batch File")
  """This is the actual method perform the Webcat actions based on the Batch CSV file.
  This method reads the batch file line by line, based on the action mentioned, execution takes place.
  """
  try:
   a=self.catman_file() #creation of credential file used to turn on/off maintenance mode
   file=open(commandfile,"r")  # Opens the Batch csv file
   
   for line in file:  # looping through the file contents, For each Line perform actions based on command
    if len(line.strip()) == 0: #skip any null line
	 continue
    if line.lower()<>'zof,,': 
	 line=self.string_comma(line)
    
    currentline=line.split(",")
    
    print("\n\n"+currentline[0]+" "+currentline[1]+" "+currentline[2].rstrip())
    log="\n\n\n"+currentline[0]+" "+currentline[1]+" "+currentline[2].rstrip()
    efile=open(self.errorLog,"a+")
    efile.write(log)
    efile.close()
    #self.log_writer(self.errorLog,log)
    currentline[1]=self.string_clean(currentline[1])
    
    
    if currentline[0].lower()=="action" or currentline[0].lower()=="zof":   #Skips the Header and Footer parameters in batch file
     continue
	 
    elif currentline[0].lower()=="archive":   #ARCHIVE Action
     #self.print_to_screen(currentline[2].rstrip())# Printing the Folder\CatalogName to the console.
     if currentline[1].lower() not in ['"/shared"','/shared','"/system"','/system','"/users"','/users']:
      """If condition restricts to take ARCHIVE of shared,systems and Users folder """
      if currentline[2].rfind('\\')<>-1:
       """this conditions splits the Folder name and catalog name,creates the project folder under Backup Location."""
       projfolder=currentline[2][:currentline[2].rfind('\\')]
       #print(projfolder)
       if os.path.exists(os.path.join(self.backup,self.foldername,projfolder))==0:
        os.makedirs(os.path.join(self.backup,self.foldername,projfolder)) #command to create folder
      else: #Else part if only Catalog Name is mentioned.
	   self.print_to_screen(currentline[2].rstrip())
      currentline[1]=currentline[1].replace("/Shared Folders","/shared")
      cmd=self.runcatPath+" -cmd archive -offline "+self.catalogPath+" -outputFile "+os.path.join(self.backup,self.foldername,currentline[2].rstrip())+".catalog -folder "+currentline[1]
      self.print_to_screen(cmd) # Print Command passed to console
      os.system(cmd+">> "+self.errorLog+" 2>&1") #Archive Command Execution self.log_writer(self.errorLog,db)
      self.log_writer(self.outBatch,line.replace("ARCHIVE","UNARCHIVE"))
      self.log_writer(self.actionLog,"\n<"+datetime.datetime.now().strftime('%b %d, %Y %I:%M:%S %p')+">"+",ARCHIVE,"+os.getlogin()+" "+cmd+";") 
     else:
	  db="\n Given Path cannot be archived"
	  self.log_writer(self.errorLog,db)
	  
	  

	 
    elif currentline[0].lower()=="unarchive": #UNARCHIVE Action
	 self.maintenance_mode()
	 catalogfile=os.path.join(self.ifilePath,currentline[2].rstrip())+".catalog"
	 if os.path.isfile(catalogfile) and catalogfile[-8:].lower()=='.catalog':
	  destcatalogfile=os.path.join(self.deployment,self.foldername,currentline[2][currentline[2].rfind('\\')+1:].rstrip()+".catalog")
	  
	  #copyfile(catalogfile,destcatalogfile)	 
	  currentline[1]=currentline[1][:currentline[1].rfind('/')]+'"'
      
	  cmd=self.runcatPath+" -cmd unarchive -offline "+self.catalogPath+" -folder "+currentline[1]+" -acl preserve -overwrite all"+" -inputFile "+os.path.join(self.ifilePath,currentline[2].rstrip())+".catalog"
	  #self.print_to_screen(cmd)
	  print(cmd)
	  os.system(cmd+">> "+self.errorLog+" 2>&1")
	  self.log_writer(self.actionLog,"\n<"+datetime.datetime.now().strftime('%b %d, %Y %I:%M:%S %p')+">"+",UNARCHIVE,"+os.getlogin()+" "+cmd+";")
	 else:
	  db="\n Catalog File not found in input location"
	  self.log_writer(self.errorLog,db)
	  print("Catalog File Not available")

    elif currentline[0].lower()=="unarchivei": #UNARCHIVE Action
	 self.maintenance_mode()
	 catalogfile=os.path.join(self.ifilePath,currentline[2].rstrip())+".catalog"
	 if os.path.isfile(catalogfile) and catalogfile[-8:].lower()=='.catalog':
	  destcatalogfile=os.path.join(self.deployment,self.foldername,currentline[2][currentline[2].rfind('\\')+1:].rstrip()+".catalog")
	  
	  #copyfile(catalogfile,destcatalogfile) #currentline[1]=currentline[1].replace("/Shared Folders","/shared")
	  currentline[1]=currentline[1].replace("/Shared Folders","/shared")   
	  currentline[1]=currentline[1][:currentline[1].rfind('/')]+'"'
	  cmd=self.runcatPath+" -cmd unarchive -offline "+self.catalogPath+" -folder "+currentline[1]+" -acl inherit -overwrite all"+" -inputFile "+os.path.join(self.ifilePath,currentline[2].rstrip())+".catalog"
	  self.print_to_screen(cmd)
	  os.system(cmd+">> "+self.errorLog+" 2>&1")
	  self.log_writer(self.actionLog,"\n<"+datetime.datetime.now().strftime('%b %d, %Y %I:%M:%S %p')+">"+",UNARCHIVE,"+os.getlogin()+" "+cmd+";")
	 else:
	  db="\n Catalog File not found in input location"
	  self.log_writer(self.errorLog,db)
	  print("Catalog File Not available")


	  
    elif currentline[0].lower()=="replace":
	 self.maintenance_mode()
	 catalogfile=os.path.join(self.ifilePath,currentline[2].rstrip())+".catalog" 
	 if os.path.isfile(catalogfile) and catalogfile[-8:].lower()=='.catalog' and currentline[1].lower() not in ['"/shared"','/shared','"/system"','/system','"/users"','/users']:
	  destcatalogfile=os.path.join(self.deployment,self.foldername,currentline[2][currentline[2].rfind('\\')+1:].rstrip()+".catalog")
	  
	  #copyfile(catalogfile,destcatalogfile) 
 	  currentline[1]=currentline[1].replace("/Shared Folders","/shared")
	  #cmd=self.runcatPath+" -cmd archive -offline "+self.catalogPath+" -outputFile "+os.path.join(self.backup,self.foldername,currentline[2].rstrip())+"_auto.catalog -folder "+currentline[1]
	  #os.system(cmd+">> "+self.errorLog+" 2>&1")
	  #print("Catalog File Backup Created at:"+os.path.join(self.backup,self.foldername,currentline[2].rstrip())+".catalog")      
	  cmd=self.runcatPath+" -cmd delete -offline "+self.catalogPath+" -path "+currentline[1]
	  self.print_to_screen("Delete Command\n"+cmd)
	  os.system(cmd+">> "+self.errorLog+" 2>&1")
	  filepath=currentline[1][:currentline[1].rfind('/')]+'"'
	  cmd=self.runcatPath+" -cmd unarchive -offline "+self.catalogPath+" -folder "+filepath+" -inputFile "+os.path.join(self.ifilePath,currentline[2].rstrip())+".catalog"+" -acl preserve -overwrite all"
	  os.system(cmd+">> "+self.errorLog+" 2>&1")
	  self.print_to_screen("Replace Command\n"+cmd)
	  self.log_writer(self.actionLog,"\n<"+datetime.datetime.now().strftime('%b %d, %Y %I:%M:%S %p')+">"+",REPLACE,"+os.getlogin()+" "+cmd+";")
	  print("Replace Completed")
	  	
	 else:
	  db="\nCatalog File not found in input location or the given file cannot be replaced."
	  self.log_writer(self.errorLog,db)
	  print("Catalog File not replaced")
	  
    elif currentline[0].lower()=="delete":
	 self.maintenance_mode()	
	 if currentline[1].lower() not in ['"/shared"','/shared','"/system"','/system','"/users"','/users']:
	  # Take Backup of file before deleting under Backup folder with name starting with auto_
	  if currentline[2].rfind('\\')<>-1:
	   currentline[2]=currentline[2][currentline[2].rfind('\\'):]
	  cmd=self.runcatPath+" -cmd archive -offline "+self.catalogPath+" -outputFile "+os.path.join(self.backup,self.foldername,currentline[2].rstrip())+"_auto.catalog -folder "+currentline[1]
	  os.system(cmd+">> "+self.errorLog+" 2>&1")
	  print("Catalog File Backup Created at:"+os.path.join(self.backup,self.foldername,currentline[2].rstrip())+".catalog")
	  cmd=self.runcatPath+" -cmd delete -offline "+self.catalogPath+" -path "+currentline[1]
	  os.system(cmd+">> "+self.errorLog+" 2>&1")
	  self.log_writer(self.actionLog,"\n<"+datetime.datetime.now().strftime('%b %d, %Y %I:%M:%S %p')+">"+",DELETE,"+os.getlogin()+" "+cmd+";")
	  print("Delete Command\n"+cmd)
	 else:
	  db="Given File path or folder path cannot be deleted"
	  self.log_writer(self.errorLog,db)
	  print(db)
	  
    else:
	 self.log_writer(self.errorLog,"Incorrect Action. Please check the Batch File")
	 

  finally:
   mcmd=self.runcatPath+" -cmd maintenanceMode -off -online "+self.srvcurl+" -credentials "+self.catmanFile
   os.system(mcmd+">> "+self.errorLog+" 2>&1")
   os.remove(self.catmanFile)
   
   file.close()
   
      
  
 def script_start(self,zipfilen):
  """This is the starting point of the script, this method determines whether the input file is CSV or ZIP file type
  _if ZIP file is detected, unzip the file contents under deployment location, look for Batch.csv file, detemine the input file location, start executing the CSV file
  for example : if Batch.csv file is located under 
  G:\99_Deployments\WebCat_Auto\20181109_131228\obiee-app-12.5.4\app\12c\Deployment\20181026\Batch.csv
  commandfile location = G:\99_Deployments\WebCat_Auto\20181109_131228\obiee-app-12.5.4\app\12c\Deployment\20181026\Batch.csv
  Input File Location (ifilePath) = G:\99_Deployments\WebCat_Auto\20181109_131228\obiee-app-12.5.4\app\12c\Deployment\20181026 i.e the catalog files to unarchive are present in this folder.   
  if CSV file is decteted,check the file name is Batch.csv, files from Standard Input Location(G:\\Input) will be used for execution"""
 
  try:
   #commandfile=''
   print(zipfilen)
   
   if os.path.isfile(zipfilen) and zipfilen[-4:]=='.zip': #chekcing the file is zip file or not
	print("Zip File Detected")
	
	unzipcmd="7z x "+zipfilen+" -o"+os.path.join(self.deployment,self.foldername) #command to unzip the contents to Deployment Location.
	print(unzipcmd)
	os.system(unzipcmd+" > null 2>&1")
	print("unzipped")
	deppath=os.path.join(self.deployment,self.foldername)
	zip_ref=zipfile.ZipFile(zipfilen,'r')  # Python method to open and read zipFile
	for zipfilename in zip_ref.namelist():	# For Loop to look for Batch.csv file inside the ZipFile
	 if os.path.isfile(os.path.join(deppath,zipfilename)) and (os.path.join(deppath,zipfilename)[-9:]=='batch.csv' or os.path.join(deppath,zipfilename)[-9:]=='Batch.csv'):
	  commandfile=os.path.join(deppath,zipfilename) #Batch File path detected from Zip File
	  print(commandfile)
	if commandfile=='':
	 log=open(self.errorLog,"w+")  # Else write to the log file if not Zip file or CSV file
	 log.write("Batch file does not exist in given zipfile\n") 
	 log.close()
	 print("Batch file does not exist in given zipfile Exiting.....")
	 return
	self.ifilePath=commandfile[:commandfile.rfind('\\')] #Input file Path detected from Zip File
	print(self.ifilePath)
	
	
	
   elif os.path.isfile(zipfilen) and (zipfilen[-9:]=='batch.csv'or zipfilen[-9:]=='Batch.csv'): #chekcing the file is CSV file or not
    print("CSV File Detected")
    commandfile=zipfilen
    self.ifilePath=commandfile[:commandfile.rfind('\\')] # Set Given Path is Batch File Location.
    print(self.ifilePath)
   else:
    log=open(self.errorLog,"w+")  # Else write to the log file if not Zip file or CSV file
    log.write("Given Zip File or Batch file does not exist\n") 
    log.close()
    print("Given Zip File\Batch file does not exist. Please try again. Exiting.....")
    return
   self.log_rotate()  #Invoke Log Rotate method
   file=open(self.errorLog,"w+")
   file.close()
   itr=1
   if itr==1 and commandfile <> '':   # Below section will sort the Batch CSV File contents.        This is to ensure the Commands in Proper Order.
    file=open(commandfile,"r")
    data=file.readlines()
    data.sort()
    file.close()
    file=open(commandfile,"w")
    for i in range(len(data)):
     file.write(data[i])
    file.close()
    getOption=1 
    if getOption==1:
     status=self.archive_webcat(commandfile) #Invoke processing the Batch File.
     if status==0:
      print("Archive Completed")
   
    elif getOption==99:
     if len(os.listdir(os.path.join(self.backup,self.foldername)))==0:
      os.rmdir(os.path.join(self.backup,self.foldername))
     if len(os.listdir(os.path.join(self.deployment,self.foldername)))==0:
      os.rmdir(os.path.join(self.deployment,self.foldername))	
     
    else:
     print("Option does not exists, Please enter correct Option")   
    itr=getOption
   else:
    log=open(self.errorLog,"a+")  # Else write to the log file if not Zip file or CSV file
    log.write("Command file is empty or command file does not exist\n") 
    log.close()
    
    
  finally:
   status=self.error_validator()
   #print("nothing")
   if len(os.listdir(os.path.join(self.backup,self.foldername)))==0:
    os.rmdir(os.path.join(self.backup,self.foldername))
   if len(os.listdir(os.path.join(self.deployment,self.foldername)))==0:
    os.rmdir(os.path.join(self.deployment,self.foldername))
   exit()
	

 def catman_file(self):
  """method creates credential files for turning on/off maintenance mode """
  try:
   file=open(self.catmanFile,"w+")
   file.write("login="+self.obiUsername+"\n")
   file.write("pwd="+self.obiPassword)
   file.close()
  finally:
   file.close()
 
 def log_writer(self,filename,cmd):
  """method to write the logs to the given file. """
  file=open(filename,"a+")
  file.write(cmd)
  file.close()
 
  
 def string_clean(self,stringInput):
  """method to escape the special characters in the string
  """
  stringInput=stringInput.replace('\\','\\\\')
  stringInput=stringInput.replace('~','\~')
  stringInput=stringInput.replace('*','\*')
  stringInput=stringInput.replace('%','%%')
  stringInput=stringInput.replace('?','\?')
  stringInput=stringInput.replace('ZOQ',',')
  stringInput=stringInput.replace('ZOZ','\/')
  return stringInput
 
 def print_to_screen(self,printString):
  print(printString)
 
 def string_comma(self,comstrInput):
  comstrInput=comstrInput.replace(',,','ZOQ')
  comstrInput=comstrInput.replace('\/','ZOZ')
  return comstrInput
 
 def maintenance_mode(self):
  
  if(self.maintenanceInd=="OFF"): #Check if the Maintenance Mode is off, if yes, then TURN ON Maintenance Mode.  
   mcmd=self.runcatPath+" -cmd maintenanceMode -on -online "+self.srvcurl+" -credentials "+self.catmanFile #Command to Turn On Maintenance Mode.
   os.system(mcmd+">> "+self.errorLog+" 2>&1")
   self.maintenanceInd="ON" # Set the Maintenance Mode Indicator as ON
  else:
   return
   
   
 def log_rotate(self):
  """ This method will rotate the error log file(G:\\OBIRBCCM\\log\\auto_wclog.log). 
  On Script invoke, this method will perform the following 
  1. make a copy of error log(G:\\OBIRBCCM\\log\\auto_wclog.log) under G:\\OBIRBCCM\\log\\logarchive with datetimestamp
  2. Under Logarchive folder, deletes the files older than 30 days from the time of script execution. 
  """
  if os.path.isfile(self.errorLog):

   lt=os.path.getmtime(os.path.join(self.errorLog))
   arclogfile=self.logarchiveFolder+"\\"+"auto_wclog_"+datetime.datetime.fromtimestamp(lt).strftime('%Y%m%d_%H%M%S')+".log"
   copyfile(self.errorLog,arclogfile) # Performs file copy operation to logarchive folder.
   now=datetime.datetime.now() #get the current datetime 2018-11-19 10:22:10.242000
   arch5=datetime.timedelta(30) #Day Parameter: 30 days, 0:00:00
   cutoff=now-arch5 # Determines the cutoff Date  2018-10-20 10:22:10.242000
   files=os.listdir(self.logarchiveFolder)  #get the file names under log archive folder
   for file in files:
     #for each file get the time stamp, compare with cutoff time, if filestamp is less then cutoff, then remove the file.
     if os.path.isfile((os.path.join(self.logarchiveFolder,file))):
      t=os.path.getmtime(os.path.join(self.logarchiveFolder,file))
      ct=datetime.datetime.fromtimestamp(t)
      if ct < cutoff:
       os.remove(os.path.join(self.logarchiveFolder,file)) #print(os.path.join(self.logarchiveFolder,file)) # Remove File
  else:
   log=open(self.errorLog,"w+")
   log.close()
  
 def error_validator(self):
  """This method is to validate the error logged in the log file (auto_wclog.log) and create custom message in log file used 
  in ITRS for monitoring.
  This method will compare the log data with the error list in the webcat config file.  
  If any error occurs, then create a custom error message "Script Failed. Please check Logs", logged at the end of the log file
  If no error occurs, then it logs custom success message "Script Execution Successful", logged at the end of the log file.
  """
  valid=0  
  for list in self.wcerrList:   
   #Read Error List one by one and find whether this error pattern occurs in Log file
   pattern=re.compile(list)
   log=open(self.errorLog,"r")
   data=log.read()
   if re.search(pattern,data): 
    print(pattern)
    valid=1
    break
   log.close() 
  log=open(self.errorLog,"a+")
  if valid==1:
   log.write("Script Failed. Please check Logs")
   log.close()
   #print("if")
  else: 
   log.write("Script Execution Successful")
   log.close()
   #print("else") 

obj=WebcatTools()   #instance for Script Class
"""Start execution by invoking script_start method, sys.argv[1] - is the input file passed from Batch file
Input file will be either Batch File or Zip File.
"""
script_start=obj.script_start(sys.argv[1]) 